import React, { Component } from 'react';

class SysAdminLogin extends Component {
  render() {
    return (
      <div className="SysAdminLogin">
        <p>yolo</p>
      </div>
    );
  }
}

export default SysAdminLogin;

