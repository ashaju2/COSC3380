import React, { Component } from 'react';

class Login extends Component {
  constructor(){
    super();
    this.state = {
      login: {}
    };

  }

  render() {
    return (
      <div className="Login">

      </div>
    );
  }
}


export default Login;

