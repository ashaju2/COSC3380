import React, { Component } from 'react';

class about extends Component {
  render() {
    return (
      <div className="about">
        <div className="jumbotron">
          <center><h2>About</h2></center>
          <center><div className="well">
            <h4><p>Clinic 17 Health Group
             We are a group of doctors dedicated to continuing patient health.
             We have specialists and primary care physicians. New patients can sign up for an
             appointment with any of our doctors.</p>
             <p>
              Our address is:

              3244 Fake St
              Houston, TX 77079

              Phone number:
              832-999-9999</p></h4>
          </div></center>
        </div>
      </div>
    );
  }
}

export default about;

